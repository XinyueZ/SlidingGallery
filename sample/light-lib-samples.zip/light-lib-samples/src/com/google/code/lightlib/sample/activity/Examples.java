/**
 * Copyright (C) 2012 Chris Xinyue Zhao <hasszhao@gmail.com>
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.google.code.lightlib.sample.activity;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.text.TextUtils;
import android.view.Window;

import com.google.code.lightlib.sample.R;
import com.google.code.lightlib.sample.fragment.ExampleBackend;
import com.google.code.lightlib.sample.fragment.ExampleList;
import com.google.code.lightlib.sample.fragment.ExampleList.OnExampleItemClickedListener;
import com.google.code.lightlib.sample.fragment.ExampleSlideGallery;
import com.google.code.lightlib.sample.fragment.ExampleSmallerSlideGallery;

/**
 * Center that controls all fragments.
 * @author Chris.Z <hasszhao@gmail.com>
 *
 */
public class Examples extends FragmentActivity implements OnExampleItemClickedListener
{
    @Override
    protected void onCreate( Bundle _arg0 ) {
        super.onCreate( _arg0 );
        requestWindowFeature( Window.FEATURE_INDETERMINATE_PROGRESS );
        requestWindowFeature( Window.FEATURE_PROGRESS );
        setContentView( R.layout.ll_examples );
        initView();
        setProgressBarIndeterminateVisibility( false );
        setProgressBarVisibility( false );
    }

    /**
     * Init the views.
     */
    private void initView() {
        FragmentManager mgr = getSupportFragmentManager();
        FragmentTransaction trans = mgr.beginTransaction();
        trans.add( R.id.rl_fl_list_container,
                Fragment.instantiate( getApplicationContext(), ExampleList.class.getName() ) );
        trans.commit();
    }

    /**
     * Open backend example.
     */
    private void openBackendExample() {
        FragmentManager mgr = getSupportFragmentManager();
        FragmentTransaction trans = mgr.beginTransaction();
//        trans.setCustomAnimations( R.anim.ll_anim_slide_in_up, R.anim.ll_anim_slide_out_down,
//                R.anim.ll_anim_slide_in_up, R.anim.ll_anim_slide_out_down );
        trans.replace( R.id.rl_fl_list_container,
                Fragment.instantiate( getApplicationContext(), ExampleBackend.class.getName() ) );
        trans.addToBackStack( null );
        trans.commit();
    }

 
    /**
     * Open sliding gallery example.
     */
    private void openSlidingGalleryExample() {
        FragmentManager mgr = getSupportFragmentManager();
        FragmentTransaction trans = mgr.beginTransaction();
//        trans.setCustomAnimations( R.anim.ll_anim_slide_in_up, R.anim.ll_anim_slide_out_down,
//                R.anim.ll_anim_slide_in_up, R.anim.ll_anim_slide_out_down );
        trans.replace( R.id.rl_fl_list_container,
                Fragment.instantiate( getApplicationContext(), ExampleSlideGallery.class.getName() ) );
        trans.addToBackStack( null );
        trans.commit();
    }
    
    /**
     * Open smaller sliding gallery example.
     */
    private void openSmallerSlidingGalleryExample() {
        FragmentManager mgr = getSupportFragmentManager();
        FragmentTransaction trans = mgr.beginTransaction();
//        trans.setCustomAnimations( R.anim.ll_anim_slide_in_up, R.anim.ll_anim_slide_out_down,
//                R.anim.ll_anim_slide_in_up, R.anim.ll_anim_slide_out_down );
        trans.replace( R.id.rl_fl_list_container,
                Fragment.instantiate( getApplicationContext(), ExampleSmallerSlideGallery.class.getName() ) );
        trans.addToBackStack( null );
        trans.commit();
    }

    @Override
    public void onExampleItemClicked( String _itemName ) { 
        if( TextUtils.equals( "Backend", _itemName ) ) {
            openBackendExample();
        }
        else if( TextUtils.equals( "Sliding Gallery", _itemName ) ) {
            openSlidingGalleryExample();
        }
        else if( TextUtils.equals( "Sliding smaller Gallery", _itemName ) ) {
            openSmallerSlidingGalleryExample();
        } 
    }
}
