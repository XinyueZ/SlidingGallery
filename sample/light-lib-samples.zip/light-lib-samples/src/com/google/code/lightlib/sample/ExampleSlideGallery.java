/**
 * Copyright (C) 2012 Chris Xinyue Zhao <hasszhao@gmail.com>
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.code.lightlib.sample;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import android.os.Handler.Callback;
import android.os.Message;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.FragmentActivity;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import de.cellular.lib.lightlib.backend.LLImageResponse;
import de.cellular.lib.lightlib.backend.LLRequest;
import de.cellular.lib.lightlib.backend.LLRequestImage;
import de.cellular.lib.lightlib.backend.LLRequestImage.RequestedSize;
import de.cellular.lib.lightlib.log.LLL;
import de.cellular.lib.lightlib.ui.view.gallery.LLAsyncGallery;
import de.cellular.lib.lightlib.ui.view.gallery.LLGallery;
import de.cellular.lib.lightlib.ui.view.gallery.LLGallery.CommentPosition;

public class ExampleSlideGallery extends FragmentActivity implements Callback, LLGallery.OnItemClickListener,
        LLGallery.OnItemScrolledListener, LLGallery.OnItemScrollListener
{
    private final static String[] SRC_URLs = {
                                           "http://imgk.zol.com.cn/ideapad/3056/a3055449_s.jpg",
                                           "http://imgk.zol.com.cn/ideapad/3056/a3055454_s.jpg",
                                           "http://imgk.zol.com.cn/ideapad/3056/a3055446_s.jpg",
                                           "http://imgk.zol.com.cn/ideapad/3056/a3055436_s.jpg",
                                           };
    private ArrayList<Bitmap>     mBitmaps = new ArrayList<Bitmap>();

    private int                   mCur     = 0;
    private LLRequest             mRequest;
    private DisplayMetrics        metrics;
    private RequestedSize         mReqSize = new RequestedSize();

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if( mRequest != null ) {
            mRequest.abort();
            mRequest = null;
        }

        if( mAsyncGallery != null ) {
            mAsyncGallery.release();
        }
    }

    @Override
    protected void onCreate( Bundle _savedInstanceState ) {
        super.onCreate( _savedInstanceState );
        requestWindowFeature( Window.FEATURE_INDETERMINATE_PROGRESS );
        requestWindowFeature( Window.FEATURE_PROGRESS );

        setContentView( R.layout.ll_slide_gallery );
        metrics = new DisplayMetrics();
        ((WindowManager) getSystemService( Context.WINDOW_SERVICE )).getDefaultDisplay().getMetrics( metrics );

        mReqSize.reqWidth = metrics.widthPixels;
        mReqSize.reqHeight = metrics.heightPixels;

        mRequest = LLRequestImage.start(
                getApplicationContext(),
                new Handler( this ),
                LLRequest.Method.GET,
                SRC_URLs[mCur],
                mReqSize,
                null );

        bindBitmapsAsynchronized( R.id.ll_empty_gallery );
    }

    private LLAsyncGallery mAsyncGallery;

    private void bindBitmapsAsynchronized( int _galleryId ) {
        mAsyncGallery = new LLAsyncGallery( (LLGallery) findViewById( _galleryId ) );
        mAsyncGallery.setImages( SRC_URLs, mReqSize );
        mAsyncGallery.addComments( 
                R.layout.ll_slide_gallery_comment,
                SRC_URLs );
        mAsyncGallery.setOnItemClickListener( this );
        mAsyncGallery.setOnItemScrollListener( this );
        mAsyncGallery.setOnItemScrolledListener( this );
    }

    private void updateProgress() {
        int p = (int) ((++mCur) * (100.0 / SRC_URLs.length) * 100);
        setProgress( p );
        if( p >= 10000 ) {
            setProgressBarIndeterminateVisibility( false );
            setProgressBarVisibility( false );
        }
    }

    @Override
    public boolean handleMessage( Message _msg ) {
        switch( _msg.what )
        {
            case LLRequest.REQUEST_FAILED:
            break;
            case LLRequest.REQUEST_SUCCESSED:
            break;
            case LLRequest.REQUEST_ABORTED:
            break;
            case LLRequestImage.REQUEST_IMAGE_SUCCESSED:
                updateProgress();
                mBitmaps.add( ((LLImageResponse) _msg.obj).getBitmap() );
                if( mCur < SRC_URLs.length ) {
                    mRequest = LLRequestImage.start(
                            getApplicationContext(),
                            new Handler( this ),
                            LLRequest.Method.GET,
                            SRC_URLs[mCur],
                            mReqSize,
                            null );
                }
                else {
                    bindBitmapsWithCommentTop( R.id.ll_gallery );
                    bindBitmaps( R.id.ll_auto_gallery );
                    bindBitmaps( R.id.ll_triggerable_gallery );
                    bindSmallBitmaps( R.id.ll_small_gallery_1 );
                    bindSmallBitmaps( R.id.ll_small_gallery_2 );
                    bindBitmapsWithCommentBottom( R.id.ll_big_gallery );
                }
            break;
            case LLRequestImage.REQUEST_IMAGE_FAILED:
            break;
            default:
                LLL.i( ":| Unkown event." );
            break;
        }
        return false;
    }

    private void bindBitmaps( int _galleryId ) {
        LLGallery gallery = (LLGallery) findViewById( _galleryId );
        gallery.setImages( mBitmaps );
        gallery.setOnItemClickListener( this );
        gallery.setOnItemScrollListener( this );
        gallery.setOnItemScrolledListener( this );
    }

    private void bindBitmapsWithCommentTop( int _galleryId ) {
        LLGallery gallery = (LLGallery) findViewById( _galleryId );
        gallery.setImages( mBitmaps );
        gallery.setOnItemClickListener( this );
        gallery.setOnItemScrollListener( this );
        gallery.setOnItemScrolledListener( this );
        gallery.addComments(
                R.layout.ll_slide_gallery_comment,
                CommentPosition.TOP,
                SRC_URLs );
    }

    private void bindBitmapsWithCommentBottom( int _galleryId ) {
        LLGallery gallery = (LLGallery) findViewById( _galleryId );
        gallery.setImages( mBitmaps );
        gallery.setOnItemClickListener( this );
        gallery.setOnItemScrollListener( this );
        gallery.setOnItemScrolledListener( this );
        gallery.addComments( R.layout.ll_slide_gallery_comment,
                SRC_URLs );
    }

    private void bindSmallBitmaps( int _galleryId ) {
        LLGallery gallery = (LLGallery) findViewById( _galleryId );
        gallery.setImages( mBitmaps, metrics.widthPixels / 2 );
        gallery.setOnItemClickListener( this );
        gallery.setOnItemScrollListener( this );
        gallery.setOnItemScrolledListener( this );
    }

    @Override
    public void onItemClick( final int _location, final List<Bitmap> _bitmaps ) {
        // LLL.d( "clicked:" + _location );
        if( _location >= 0 && _bitmaps != null ) {
            DialogFragment dlg = new DialogFragment() {
                @Override
                public View onCreateView(
                        LayoutInflater _inflater,
                        ViewGroup _container,
                        Bundle _savedInstanceState ) {
                    getDialog().requestWindowFeature( Window.FEATURE_NO_TITLE );
                    View v = _inflater.inflate( R.layout.ll_show_popup_image, _container );
                    ImageView iv = (ImageView) v.findViewById( R.id.iv );
                    iv.setImageBitmap( _bitmaps.get( _location ) );
                    return v;
                }
            };
            dlg.show( getSupportFragmentManager(), null );
        }
    }

    @Override
    public void onItemScroll( int _location, List<Bitmap> _bitmaps ) {
        // LLL.d( "Item is moving." );
    }

    @Override
    public void onItemScrolled( int _location, List<Bitmap> _bitmaps ) {
        // LLL.d( "Item is moved." );
    }
}
