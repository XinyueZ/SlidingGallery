/*
 * Copyright (C) 2012 Chris Xinyue Zhao <hasszhao@gmail.com>
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.code.lightlib.sample;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Handler.Callback;
import android.os.Message;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.ImageView;
import de.cellular.lib.lightlib.backend.LLImageResponse;
import de.cellular.lib.lightlib.backend.LLRequest;
import de.cellular.lib.lightlib.backend.LLRequestImage;
import de.cellular.lib.lightlib.backend.LLRequestImage.RequestedSize;
import de.cellular.lib.lightlib.backend.LLResponse;
import de.cellular.lib.lightlib.log.LLL;

public class ExampleBackend extends Activity implements Callback
{
    private EditText       mText;
    private ImageView      mImage;
    private LLRequest      mRequest;
    private DisplayMetrics metrics;

    @Override
    public void onCreate( Bundle savedInstanceState ) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.ll_backend );
        mText = (EditText) findViewById( R.id.tv_data );
        mImage = (ImageView) findViewById( R.id.iv_data );

        metrics = new DisplayMetrics();
        ((WindowManager) getSystemService( Context.WINDOW_SERVICE )).getDefaultDisplay().getMetrics(
                metrics );
    }

    @Override
    protected void onPause() {
        super.onPause();
        if( mRequest != null ) {
            mRequest.abort();
        }
    }

    @Override
    public boolean handleMessage( Message _msg ) {
        switch( _msg.what )
        {
            case LLRequest.REQUEST_FAILED:
            break;
            case LLRequest.REQUEST_SUCCESSED:
                mText.setText( ((LLResponse) _msg.obj).toString() );
            break;
            case LLRequest.REQUEST_ABORTED:
            break;
            case LLRequestImage.REQUEST_IMAGE_SUCCESSED:
                mImage.setImageBitmap( ((LLImageResponse) _msg.obj).getBitmap() );
            break;
            case LLRequestImage.REQUEST_IMAGE_FAILED:
            break;
            default:
                LLL.i( ":| Unkown event." );
            break;
        }
        return false;
    }

    public void push( View _v ) {
        if( mRequest != null ) {
            mRequest.abort();
        }

        mRequest = LLRequest.start(
                getApplicationContext(),
                new Handler( this ),
                LLRequest.Method.GET,
                "http://m.otto.de/?getAndroidFeed=1&view=AppWebShop_Android&udid=45645645645645",
                null );
    }

    public void load( View _v ) {
        if( mRequest != null ) {
            mRequest.abort();
        } 
        RequestedSize size = new RequestedSize();
        size.reqWidth = metrics.widthPixels;
        size.reqHeight = metrics.heightPixels;
        
        mRequest = LLRequestImage.start(
                getApplicationContext(),
                new Handler( this ),
                LLRequest.Method.GET,
                "http://mobil.otto.de/ottoproj/wap/aktionen2012/sommerkleider_kw23.jpg",
                size,
                null );
    }
}
