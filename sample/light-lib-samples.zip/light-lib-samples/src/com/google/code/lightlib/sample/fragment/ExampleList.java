/**
 * Copyright (C) 2012 Chris Xinyue Zhao <hasszhao@gmail.com>
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.google.code.lightlib.sample.fragment;

import android.app.Activity;
import android.os.Bundle;
import android.support.v4.app.ListFragment;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import de.cellular.lib.lightlib.log.LLL;

/**
 * Show a list that shows all examples.
 * @author Chris.Z <hasszhao@gmail.com>
 *
 */
public class ExampleList extends ListFragment
{
    private final static String[] MENU = { "Backend", "Sliding Gallery", };
    private ArrayAdapter<String>  mAdapter;

    /**
     * Listener for clicked-event on the ListView.
     */
    public interface OnExampleItemClickedListener {
        /**
         * The response when a list item is clicked.
         * 
         * @param _itemName
         *            the text/name of the clicked item.
         */
        void onExampleItemClicked( String _itemName );
    }

    private OnExampleItemClickedListener mOnExampleItemClickedListener;

    @Override
    public void onAttach( Activity _activity ) {
        super.onAttach( _activity );
        mAdapter = new ArrayAdapter<String>( _activity.getApplicationContext(), android.R.layout.simple_list_item_1,
                MENU );

        if( _activity instanceof OnExampleItemClickedListener ) {
            setOnExampleItemClickedListener( (OnExampleItemClickedListener) _activity );
        }
        else {
            LLL.e( _activity.toString() +
                    " must implement OnExampleItemClickListener" );
        }
    }

    @Override
    public void onActivityCreated( Bundle _savedInstanceState ) {
        super.onActivityCreated( _savedInstanceState );
        if( mAdapter != null ) {
            setListAdapter( mAdapter );
        }
        else {
            LLL.e( "Adapter is NULL." );
        }
    }

    @Override
    public void onListItemClick( ListView _l, View _v, int _position, long _id ) {
        super.onListItemClick( _l, _v, _position, _id );
        onExampleItemClicked( MENU[_position] );
    }

    /**
     * Event fired when list item is clicked.
     * 
     * @param _itemName
     */
    private void onExampleItemClicked( String _itemName ) {
        if( null != mOnExampleItemClickedListener ) {
            mOnExampleItemClickedListener.onExampleItemClicked( _itemName );
        }
    }

    /**
     * The UI that listen on this fragment can change UI that represent the example.
     * 
     * @param _onExampleItemClickedListener
     *            the onExampleItemClickedListener to set
     */
    public void setOnExampleItemClickedListener( OnExampleItemClickedListener _onExampleItemClickedListener ) {
        mOnExampleItemClickedListener = _onExampleItemClickedListener;
    }
}
